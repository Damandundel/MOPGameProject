const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');

const assets = { bg: new Image(), player: new Image(), ai: new Image() };
assets.bg.src = 'assets/bg.png';
assets.player.src = 'assets/player.png';
assets.ai.src = 'assets/enemy.png';

const audio = {
    cast: new Audio('assets/cast.wav'),
    hit: new Audio('assets/hit.wav'),
    charge: new Audio('assets/charge.wav'),
    ultimate: new Audio('assets/ultimate.wav')
};

function playSound(id) {
    let snd = audio[id].cloneNode();
    snd.volume = 0.4;
    snd.play().catch(e => console.log("Audio play prevented until interaction"));
}

let keys = {};
let mouse = { x: 0, y: 0, down: false, holdTime: 0 };
let projectiles = [];
let particles = [];
let comboSequence = [];
let comboTimer = 0;

window.addEventListener('keydown', (e) => { keys[e.key.toLowerCase()] = true; handleCombo(e.key.toLowerCase()); });
window.addEventListener('keyup', (e) => keys[e.key.toLowerCase()] = false);
canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect(); mouse.x = e.clientX - rect.left; mouse.y = e.clientY - rect.top;
});
canvas.addEventListener('mousedown', () => mouse.down = true);
canvas.addEventListener('mouseup', () => { mouse.down = false; if(started) player.castSpell(); });

function handleCombo(key) {
    if (['q', 'w', 'e'].includes(key)) {
        comboSequence.push(key.toUpperCase()); comboTimer = 100;
        if (comboSequence.length > 3) comboSequence.shift();
        document.getElementById('combo-display').innerText = `Combo: ${comboSequence.join('-')}`;
        if (comboSequence.join('') === 'QWE') {
            player.castUltimate(); comboSequence = [];
            document.getElementById('combo-display').innerText = 'Combo: ULTIMATE!';
        }
    }
}

class Entity {
    constructor(x, y, color, sprite) {
        this.x = x; this.y = y; this.radius = 20; this.color = color;
        this.sprite = sprite; this.hp = 100; this.mana = 100; this.speed = 3; this.shield = 0;
    }
    draw() {
        if (this.shield > 0) {
            ctx.strokeStyle = '#42cbf5'; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius + 10, 0, Math.PI * 2); ctx.stroke();
        }
        if (this.sprite.complete && this.sprite.naturalWidth !== 0) {
            ctx.save(); ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.clip();
            ctx.drawImage(this.sprite, this.x - this.radius, this.y - this.radius, this.radius * 2, this.radius * 2);
            ctx.restore();
        } else {
            ctx.fillStyle = this.color; ctx.shadowBlur = 10; ctx.shadowColor = this.color;
            ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
        }
    }
}

class Player extends Entity {
    constructor() { super(100, 300, '#6e8ee0', assets.player); }
    update() {
        if (keys['w'] && this.y > this.radius) this.y -= this.speed;
        if (keys['s'] && this.y < canvas.height - this.radius) this.y += this.speed;
        if (keys['a'] && this.x > this.radius) this.x -= this.speed;
        if (keys['d'] && this.x < canvas.width - this.radius) this.x += this.speed;

        if (mouse.down && this.mana > 0) {
            mouse.holdTime++;
            if (mouse.holdTime === 20) playSound('charge');
            if (mouse.holdTime > 20) { this.mana -= 0.5; spawnParticles(this.x, this.y, this.color, 1); }
        }
        if (this.shield > 0) this.shield--;
        if (this.mana < 100 && !mouse.down) this.mana += 0.2;
        if (comboTimer > 0) {
            comboTimer--;
            if (comboTimer === 0) { comboSequence = []; document.getElementById('combo-display').innerText = 'Combo: '; }
        }
    }
    castSpell() {
        if (mouse.holdTime > 40) { shootProjectile(this.x, this.y, mouse.x, mouse.y, 'player', 8, 25, 15, '#e06e6e'); playSound('cast'); }
        else if (mouse.holdTime > 0) { shootProjectile(this.x, this.y, mouse.x, mouse.y, 'player', 6, 10, 5, '#e0d06e'); playSound('cast'); }
        mouse.holdTime = 0;
    }
    castUltimate() {
        if (this.mana >= 50) {
            this.mana -= 50; playSound('ultimate');
            for(let i=0; i<8; i++) {
                let angle = (Math.PI * 2 / 8) * i;
                shootProjectile(this.x, this.y, this.x + Math.cos(angle)*100, this.y + Math.sin(angle)*100, 'player', 5, 20, 10, '#b66ee0');
            }
        }
    }
}

class AIWizard extends Entity {
    constructor() { super(700, 300, '#823b3b', assets.ai); this.state = 'IDLE'; this.stateTimer = 0; this.targetY = 300; }
    changeState(newState) { this.state = newState; this.stateTimer = 0; document.getElementById('ai-state').innerText = newState; }
    update() {
        this.stateTimer++;
        if (this.shield > 0) this.shield--;
        if (this.mana < 100 && this.state !== 'CHARGE_POWER') this.mana += 0.1;
        let incoming = this.detectIncoming();
        switch (this.state) {
            case 'IDLE':
                if (this.stateTimer % 60 === 0) this.targetY = Math.max(50, Math.min(550, this.y + (Math.random() - 0.5) * 100));
                this.moveTo(this.x, this.targetY, 1);
                if (incoming) Math.random() > 0.5 ? this.changeState('DODGE') : this.changeState('CAST_SHIELD');
                else if (this.mana < 30) this.changeState('CHARGE_POWER');
                else if (this.stateTimer > 90) this.changeState('CAST_ATTACK');
                break;
            case 'CAST_ATTACK':
                if (this.stateTimer === 10) { shootProjectile(this.x, this.y, player.x, player.y, 'ai', 5, 10, 5, '#5e9e5e'); playSound('cast'); }
                if (this.stateTimer > 30) this.changeState('IDLE');
                break;
            case 'CAST_SHIELD':
                this.shield = 60; this.changeState('IDLE');
                break;
            case 'DODGE':
                if (this.stateTimer === 1) this.targetY = this.y > 300 ? this.y - 150 : this.y + 150;
                this.moveTo(this.x, this.targetY, 6);
                if (this.stateTimer > 20) this.changeState('IDLE');
                break;
            case 'CHARGE_POWER':
                this.mana += 1; spawnParticles(this.x, this.y, '#823b3b', 2);
                if (this.stateTimer === 1) playSound('charge');
                if (incoming) this.changeState('DODGE');
                if (this.mana >= 100) this.changeState('ULTIMATE');
                break;
            case 'ULTIMATE':
                if (this.stateTimer === 30) { shootProjectile(this.x, this.y, player.x, player.y, 'ai', 7, 40, 20, '#9e3b3b'); playSound('ultimate'); }
                if (this.stateTimer > 60) this.changeState('IDLE');
                break;
        }
    }
    moveTo(tx, ty, spd) { let dy = ty - this.y; let dist = Math.abs(dy); if (dist > spd) { this.y += (dy / dist) * spd; } }
    detectIncoming() { return projectiles.some(p => p.owner === 'player' && Math.hypot(this.x - p.x, this.y - p.y) < 150); }
}

class Projectile {
    constructor(x, y, tx, ty, owner, speed, damage, radius, color) {
        this.x = x; this.y = y; this.owner = owner; this.damage = damage; this.radius = radius; this.color = color;
        let angle = Math.atan2(ty - y, tx - x); this.vx = Math.cos(angle) * speed; this.vy = Math.sin(angle) * speed;
    }
    update() { this.x += this.vx; this.y += this.vy; spawnParticles(this.x, this.y, this.color, 1); }
    draw() {
        ctx.fillStyle = this.color; ctx.shadowBlur = 15; ctx.shadowColor = this.color;
        ctx.beginPath(); ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
    }
}

function shootProjectile(x, y, tx, ty, owner, speed, damage, size, color) { projectiles.push(new Projectile(x, y, tx, ty, owner, speed, damage, size, color)); }
function spawnParticles(x, y, color, count) {
    for(let i=0; i<count; i++) particles.push({ x: x + (Math.random() - 0.5) * 10, y: y + (Math.random() - 0.5) * 10, vx: (Math.random() - 0.5) * 2, vy: (Math.random() - 0.5) * 2, life: 20, color: color });
}

const player = new Player();
const ai = new AIWizard();

function drawEnvironment() {
    if (assets.bg.complete && assets.bg.naturalWidth !== 0) {
        ctx.globalAlpha = 0.4; // Darken bg
        ctx.drawImage(assets.bg, 0, 0, canvas.width, canvas.height);
        ctx.globalAlpha = 1.0;
    } else { ctx.clearRect(0, 0, canvas.width, canvas.height); }
}

function updateUI() {
    document.getElementById('player-hp').style.width = Math.max(0, player.hp) + '%';
    document.getElementById('player-mana').style.width = Math.max(0, player.mana) + '%';
    document.getElementById('ai-hp').style.width = Math.max(0, ai.hp) + '%';
}

function gameLoop() {
    drawEnvironment();
    if (player.hp > 0 && ai.hp > 0) { player.update(); ai.update(); }
    player.draw(); ai.draw();

    for (let i = projectiles.length - 1; i >= 0; i--) {
        let p = projectiles[i]; p.update(); p.draw();
        if (p.x < 0 || p.x > canvas.width || p.y < 0 || p.y > canvas.height) { projectiles.splice(i, 1); continue; }
        if (p.owner === 'player' && Math.hypot(p.x - ai.x, p.y - ai.y) < ai.radius + p.radius) {
            if (ai.shield <= 0) { ai.hp -= p.damage; playSound('hit'); }
            projectiles.splice(i, 1); continue;
        }
        if (p.owner === 'ai' && Math.hypot(p.x - player.x, p.y - player.y) < player.radius + p.radius) {
            if (player.shield <= 0) { player.hp -= p.damage; playSound('hit'); }
            projectiles.splice(i, 1); continue;
        }
    }

    for (let i = particles.length - 1; i >= 0; i--) {
        let pt = particles[i]; pt.x += pt.vx; pt.y += pt.vy; pt.life--;
        ctx.fillStyle = pt.color; ctx.globalAlpha = pt.life / 20;
        ctx.fillRect(pt.x, pt.y, 3, 3); ctx.globalAlpha = 1.0;
        if (pt.life <= 0) particles.splice(i, 1);
    }
    updateUI();
    
    if (player.hp <= 0) { ctx.fillStyle = 'red'; ctx.font = '30px "Press Start 2P"'; ctx.fillText("YOU DIED", 250, 300); }
    else if (ai.hp <= 0) { ctx.fillStyle = 'green'; ctx.font = '30px "Press Start 2P"'; ctx.fillText("VICTORY", 270, 300); }
    else { requestAnimationFrame(gameLoop); }
}

let started = false;
window.addEventListener('click', () => {
    if (!started) { started = true; playSound('charge'); gameLoop(); }
}, {once: true});

// Initial boot state
assets.bg.onload = drawEnvironment;
setTimeout(() => {
    drawEnvironment();
    ctx.fillStyle = 'white'; ctx.font = '20px "Press Start 2P"'; ctx.fillText("CLICK TO START", 220, 300);
}, 500);
