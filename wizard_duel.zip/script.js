const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
ctx.imageSmoothingEnabled = false;

// Arena Constants - Much Bigger
const CX = canvas.width / 2;
const CY = canvas.height / 2;
const ARENA_RADIUS = 460; 

const audio = {
    cast: new Audio('assets/cast.wav'),
    hit: new Audio('assets/hit.wav'),
    charge: new Audio('assets/charge.wav'),
    ultimate: new Audio('assets/ultimate.wav')
};

function playSound(id) {
    let snd = audio[id].cloneNode(); 
    snd.volume = 0.3; 
    snd.play().catch(e => {});
}

let keys = {};
let mouse = { x: 0, y: 0, down: false, holdTime: 0 };
let projectiles = [];
let particles = [];
let comboSequence = [];
let comboTimer = 0;
let currentWave = 1;
let enemies = [];
let started = false;
let gameOver = false;

// Track inputs for combo buffer on press, NOT on hold
window.addEventListener('keydown', (e) => { 
    let key = e.key.toLowerCase();
    if (!keys[key]) { // Only trigger if it wasn't already held down
        handleCombo(key);
    }
    keys[key] = true; 
});
window.addEventListener('keyup', (e) => keys[e.key.toLowerCase()] = false);

canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect(); 
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    mouse.x = (e.clientX - rect.left) * scaleX; 
    mouse.y = (e.clientY - rect.top) * scaleY;
});
canvas.addEventListener('mousedown', () => mouse.down = true);
canvas.addEventListener('mouseup', () => { mouse.down = false; if(started && player.hp > 0 && !gameOver) player.castSpell(); });

function handleCombo(key) {
    // We now log WASD movements into the buffer as well!
    if (['q', 'w', 'e', 'a', 's', 'd'].includes(key) && player.hp > 0 && !gameOver) {
        comboSequence.push(key.toUpperCase()); 
        comboTimer = 100; // Timer reset
        if (comboSequence.length > 3) comboSequence.shift();
        
        document.getElementById('combo-display').innerText = `Buffer: [${comboSequence.join('-')}]`;
        
        let seq = comboSequence.join('');
        if (seq.length === 3) {
            let success = false;
            if (seq === 'QWE') { player.castUltimate(); success = true; }
            else if (seq === 'QQQ') { player.buffs.rapidFire = 180; success = true; playSound('charge'); }
            else if (seq === 'EEE') { player.shield = 150; success = true; playSound('charge'); }
            // New Directional Dashes
            else if (seq === 'WWW') { player.dashDir(0, -1); success = true; playSound('cast'); }
            else if (seq === 'SSS') { player.dashDir(0, 1); success = true; playSound('cast'); }
            else if (seq === 'AAA') { player.dashDir(-1, 0); success = true; playSound('cast'); }
            else if (seq === 'DDD') { player.dashDir(1, 0); success = true; playSound('cast'); }
            
            if (success) {
                comboSequence = [];
                document.getElementById('combo-display').innerText = `Buffer: [EXEC]`;
                spawnParticles(player.x, player.y, '#d661ff', 20);
            }
        }
    }
}

function distance(x1, y1, x2, y2) { return Math.hypot(x2 - x1, y2 - y1); }

// BASE ENTITY
class Entity {
    constructor(x, y, isPlayer) {
        this.x = x; this.y = y; this.radius = 20; this.isPlayer = isPlayer;
        this.hp = 100; this.maxHp = 100; this.mana = 100; this.speed = 3; this.shield = 0;
        this.scale = 1;
        this.cloakColor = isPlayer ? '#56387d' : '#454a4a'; 
        this.magicColor = isPlayer ? '#00e5ff' : '#44f052'; 
    }
    
    applyBounds() {
        let dist = distance(this.x, this.y, CX, CY);
        if (dist > ARENA_RADIUS - (this.radius * this.scale)) {
            let angle = Math.atan2(this.y - CY, this.x - CX);
            this.x = CX + Math.cos(angle) * (ARENA_RADIUS - (this.radius * this.scale));
            this.y = CY + Math.sin(angle) * (ARENA_RADIUS - (this.radius * this.scale));
        }
    }
    
    draw() {
        if (this.shield > 0) {
            ctx.strokeStyle = this.isPlayer ? 'rgba(0, 229, 255, 0.6)' : 'rgba(214, 97, 255, 0.8)'; 
            ctx.lineWidth = 4;
            ctx.beginPath(); ctx.arc(this.x, this.y, (this.radius * this.scale) + 15, 0, Math.PI * 2); ctx.stroke();
        }

        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.scale(this.scale, this.scale);

        // Shadow
        ctx.fillStyle = 'rgba(0,0,0,0.6)';
        ctx.beginPath(); ctx.ellipse(0, 25, 20, 8, 0, 0, Math.PI*2); ctx.fill();
        
        // Cloak
        ctx.fillStyle = this.cloakColor;
        ctx.beginPath();
        ctx.moveTo(0, -10); ctx.lineTo(-22, 25); ctx.lineTo(22, 25); ctx.fill();
        
        ctx.fillStyle = '#2b1b40'; // Trim
        ctx.fillRect(-18, 20, 36, 5);

        // Head
        if(this.isPlayer) {
            ctx.fillStyle = '#f2c9a7'; ctx.fillRect(-10, -15, 20, 15);
            ctx.fillStyle = '#8f5c38'; ctx.fillRect(-10, 0, 20, 8); // Beard
        } else {
            ctx.fillStyle = '#1c1e1c'; ctx.fillRect(-10, -15, 20, 15);
            ctx.fillStyle = this.magicColor; // Eyes
            ctx.fillRect(-6, -10, 4, 4); ctx.fillRect(2, -10, 4, 4);
        }
        
        // Hat
        ctx.fillStyle = this.isPlayer ? '#462e66' : '#2d3030';
        ctx.beginPath(); ctx.moveTo(-25, -15); ctx.lineTo(25, -15); ctx.lineTo(0, -40); ctx.fill();
        
        // Staff
        ctx.fillStyle = '#785b41';
        let staffX = this.isPlayer ? 25 : -25;
        ctx.fillRect(staffX - 3, -20, 6, 45);
        
        ctx.fillStyle = this.magicColor;
        ctx.shadowBlur = 20; ctx.shadowColor = this.magicColor;
        ctx.beginPath(); ctx.arc(staffX, -25, 6, 0, Math.PI*2); ctx.fill();
        
        ctx.restore();

        // HP bar for AI
        if (!this.isPlayer && this.hp > 0) {
            ctx.fillStyle = '#222'; ctx.fillRect(this.x - 25, this.y - (55 * this.scale), 50, 6);
            ctx.fillStyle = '#e65c5c'; ctx.fillRect(this.x - 25, this.y - (55 * this.scale), 50 * (Math.max(0, this.hp) / this.maxHp), 6);
        }
    }
}

class Player extends Entity {
    constructor() { super(CX, CY + 200, true); this.speed = 5; this.buffs = { rapidFire: 0 }; }
    
    // New directional dash logic
    dashDir(dx, dy) {
        if(this.mana >= 30) {
            this.mana -= 30;
            spawnParticles(this.x, this.y, '#00e5ff', 20); // Leave particles at start
            let dist = 280; // Dash distance
            this.x += dx * dist;
            this.y += dy * dist;
            this.applyBounds();
            spawnParticles(this.x, this.y, '#00e5ff', 20); // Particles at end
        }
    }

    update() {
        if (keys['w']) this.y -= this.speed;
        if (keys['s']) this.y += this.speed;
        if (keys['a']) this.x -= this.speed;
        if (keys['d']) this.x += this.speed;
        this.applyBounds();

        // Auto-fire if overclocked
        if (this.buffs.rapidFire > 0) {
            this.buffs.rapidFire--;
            if (this.buffs.rapidFire % 8 === 0 && this.mana > 0) {
                shootProjectile(this.x+25, this.y-25, mouse.x, mouse.y, 'player', 12, 10, 6, '#d661ff');
                playSound('cast');
                this.mana -= 1;
            }
        }

        if (mouse.down && this.mana > 0 && this.buffs.rapidFire <= 0) {
            mouse.holdTime++;
            if (mouse.holdTime === 20) playSound('charge');
            if (mouse.holdTime > 20) { this.mana -= 0.5; spawnParticles(this.x+25, this.y-25, this.magicColor, 1); }
        }
        if (this.shield > 0) this.shield--;
        if (this.mana < 100 && !mouse.down) this.mana += 0.25;
        if (comboTimer > 0) {
            comboTimer--;
            if (comboTimer === 0) { comboSequence = []; document.getElementById('combo-display').innerText = 'Buffer: [NONE]'; }
        }
    }
    castSpell() {
        if (this.buffs.rapidFire > 0) return; // Prevent normal cast while overclocked
        if (mouse.holdTime > 40) { shootProjectile(this.x+25, this.y-25, mouse.x, mouse.y, 'player', 12, 40, 18, this.magicColor); playSound('cast'); }
        else if (mouse.holdTime > 0) { shootProjectile(this.x+25, this.y-25, mouse.x, mouse.y, 'player', 10, 15, 8, this.magicColor); playSound('cast'); }
        mouse.holdTime = 0;
    }
    castUltimate() {
        if (this.mana >= 50) {
            this.mana -= 50; playSound('ultimate');
            let ultColor = '#d661ff'; 
            for(let i=0; i<12; i++) {
                let angle = (Math.PI * 2 / 12) * i;
                shootProjectile(this.x+25, this.y-25, this.x + Math.cos(angle)*100, this.y + Math.sin(angle)*100, 'player', 7, 30, 14, ultColor);
            }
        }
    }
}

// AI ENEMY CLASSES
class DroneNode extends Entity {
    constructor(level) {
        super(CX + (Math.random() - 0.5)*900, CY - 250, false);
        this.maxHp = 30 + (level * 10); this.hp = this.maxHp;
        this.speed = 2.8 + (level * 0.2);
        this.cloakColor = '#66421c'; 
        this.magicColor = '#ff8800'; 
        this.scale = 0.7; 
        this.damage = 15 + (level * 2);
    }
    update() {
        let angle = Math.atan2(player.y - this.y, player.x - this.x);
        this.x += Math.cos(angle) * this.speed;
        this.y += Math.sin(angle) * this.speed;
        this.applyBounds();

        if (distance(this.x, this.y, player.x, player.y) < (this.radius * this.scale) + player.radius) {
            if (player.shield <= 0) { player.hp -= this.damage; playSound('hit'); }
            this.x -= Math.cos(angle) * 50;
            this.y -= Math.sin(angle) * 50;
            spawnParticles(this.x, this.y, this.magicColor, 10);
        }
    }
}

class ArtilleryNode extends Entity {
    constructor(level) {
        super(CX + (Math.random() - 0.5)*900, CY - 350, false);
        this.maxHp = 60 + (level * 15); this.hp = this.maxHp;
        this.speed = 1.2 + (level * 0.1);
        this.cloakColor = '#5c1c1c'; 
        this.magicColor = '#ff3333'; 
        this.castTimer = 0;
        this.castRate = Math.max(30, 80 - (level * 5));
    }
    update() {
        let distToPlayer = distance(this.x, this.y, player.x, player.y);
        let angle = Math.atan2(player.y - this.y, player.x - this.x);

        if (distToPlayer < 250) {
            this.x -= Math.cos(angle) * this.speed; this.y -= Math.sin(angle) * this.speed;
        } else if (distToPlayer > 350) {
            this.x += Math.cos(angle) * this.speed; this.y += Math.sin(angle) * this.speed;
        } else {
            this.x += Math.cos(angle + Math.PI/2) * (this.speed * 0.5);
            this.y += Math.sin(angle + Math.PI/2) * (this.speed * 0.5);
        }

        this.applyBounds();
        this.castTimer++;
        if (this.castTimer > this.castRate) {
            shootProjectile(this.x-25, this.y-25, player.x, player.y, 'ai', 8, 20, 6, this.magicColor);
            playSound('cast');
            this.castTimer = 0;
        }
    }
}

class JuggernautNode extends Entity {
    constructor(level) {
        super(CX, CY - 300, false);
        this.maxHp = 250 + (level * 50); this.hp = this.maxHp;
        this.speed = 0.6 + (level * 0.05);
        this.cloakColor = '#2b2b30'; 
        this.magicColor = '#d661ff'; 
        this.scale = 1.6; 
        this.castTimer = 0;
    }
    update() {
        let angleToCenter = Math.atan2(CY - this.y, CX - this.x);
        if (distance(this.x, this.y, CX, CY) > 50) {
            this.x += Math.cos(angleToCenter) * this.speed;
            this.y += Math.sin(angleToCenter) * this.speed;
        }
        
        this.applyBounds();
        this.castTimer++;

        if (this.castTimer > 150) {
            playSound('ultimate');
            spawnParticles(this.x, this.y, this.magicColor, 20);
            for(let i=0; i<8; i++) {
                let angle = (Math.PI * 2 / 8) * i;
                shootProjectile(this.x, this.y, this.x + Math.cos(angle)*100, this.y + Math.sin(angle)*100, 'ai', 5, 30, 12, this.magicColor);
            }
            this.castTimer = 0;
        }
    }
}

class Projectile {
    constructor(x, y, tx, ty, owner, speed, damage, radius, color) {
        this.x = x; this.y = y; this.owner = owner; this.damage = damage; this.radius = radius; this.color = color;
        let angle = Math.atan2(ty - y, tx - x); 
        this.vx = Math.cos(angle) * speed; 
        this.vy = Math.sin(angle) * speed;
    }
    update() { this.x += this.vx; this.y += this.vy; spawnParticles(this.x, this.y, this.color, 1); }
    draw() {
        ctx.fillStyle = this.color; ctx.shadowBlur = 20; ctx.shadowColor = this.color;
        ctx.fillRect(this.x - this.radius, this.y - this.radius, this.radius * 2, this.radius * 2);
        ctx.shadowBlur = 0;
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(this.x - this.radius*0.4, this.y - this.radius*0.4, this.radius * 0.8, this.radius * 0.8);
    }
}

function shootProjectile(x, y, tx, ty, owner, speed, damage, size, color) { projectiles.push(new Projectile(x, y, tx, ty, owner, speed, damage, size, color)); }
function spawnParticles(x, y, color, count) {
    for(let i=0; i<count; i++) particles.push({ x: x + (Math.random() - 0.5) * 15, y: y + (Math.random() - 0.5) * 15, vx: (Math.random() - 0.5) * 3, vy: (Math.random() - 0.5) * 3, life: 25, color: color });
}

const player = new Player();

function spawnWave(wave) {
    let numDrones = Math.min(10, Math.floor(wave * 1.5));
    let numArtillery = Math.min(5, Math.floor(wave / 2));
    let numJuggernauts = Math.floor(wave / 4);

    for(let i=0; i<numDrones; i++) enemies.push(new DroneNode(wave));
    for(let i=0; i<numArtillery; i++) enemies.push(new ArtilleryNode(wave));
    for(let i=0; i<numJuggernauts; i++) enemies.push(new JuggernautNode(wave));
    
    if(enemies.length === 0) enemies.push(new DroneNode(1));

    document.getElementById('wave-display').innerText = `WAVE: ${wave}`;
}

function drawDecorations() {
    // Concentric Core Rings
    ctx.beginPath(); ctx.arc(CX, CY, 100, 0, Math.PI*2);
    ctx.strokeStyle = 'rgba(0, 229, 255, 0.15)'; ctx.lineWidth = 4; ctx.stroke();
    
    ctx.beginPath(); ctx.arc(CX, CY, 180, 0, Math.PI*2);
    ctx.strokeStyle = 'rgba(214, 97, 255, 0.15)'; ctx.lineWidth = 2; ctx.stroke();

    // Circuit Board Traces
    ctx.beginPath();
    ctx.moveTo(CX - 350, CY); ctx.lineTo(CX - 150, CY); ctx.lineTo(CX - 100, CY - 50);
    ctx.moveTo(CX + 350, CY); ctx.lineTo(CX + 150, CY); ctx.lineTo(CX + 100, CY + 50);
    ctx.moveTo(CX, CY - 350); ctx.lineTo(CX, CY - 150); ctx.lineTo(CX + 50, CY - 100);
    ctx.moveTo(CX, CY + 350); ctx.lineTo(CX, CY + 150); ctx.lineTo(CX - 50, CY + 100);
    ctx.strokeStyle = 'rgba(0, 229, 255, 0.2)'; ctx.lineWidth = 3; ctx.stroke();

    // Edge Data Nodes (Logic Gates)
    const nodes = [ 
        {x: CX - ARENA_RADIUS + 20, y: CY}, 
        {x: CX + ARENA_RADIUS - 20, y: CY}, 
        {x: CX, y: CY - ARENA_RADIUS + 20}, 
        {x: CX, y: CY + ARENA_RADIUS - 20} 
    ];
    
    nodes.forEach(n => {
        ctx.fillStyle = 'rgba(43, 43, 48, 0.8)';
        ctx.strokeStyle = '#5a6266';
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.rect(n.x - 25, n.y - 25, 50, 50);
        ctx.fill(); ctx.stroke();
        
        ctx.fillStyle = 'rgba(0, 229, 255, 0.6)';
        ctx.fillRect(n.x - 8, n.y - 8, 16, 16);
    });
}

function drawEnvironment() {
    ctx.fillStyle = '#222527'; ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.beginPath(); ctx.arc(CX, CY, ARENA_RADIUS, 0, Math.PI * 2);
    ctx.fillStyle = '#1c1e1f'; ctx.fill();

    ctx.lineWidth = 14; ctx.strokeStyle = '#41474a'; ctx.stroke();
    ctx.lineWidth = 4; ctx.strokeStyle = '#141514'; ctx.stroke();

    ctx.save();
    ctx.beginPath(); ctx.arc(CX, CY, ARENA_RADIUS, 0, Math.PI * 2); ctx.clip();
    
    ctx.strokeStyle = '#262a2b'; ctx.lineWidth = 2;
    const tileSize = 60;
    let offsetX = CX % tileSize; let offsetY = CY % tileSize;

    for (let x = offsetX; x < canvas.width; x += tileSize) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
    }
    for (let y = offsetY; y < canvas.height; y += tileSize) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
    }

    // Add Schematic Decorations
    drawDecorations();

    ctx.fillStyle = '#5c6469';
    ctx.fillRect(CX - 15, CY - 3, 30, 6);
    ctx.fillRect(CX - 3, CY - 15, 6, 30);
    ctx.restore();
}

function updateUI() {
    document.getElementById('player-hp').style.width = Math.max(0, player.hp) + '%';
    document.getElementById('player-mana').style.width = Math.max(0, player.mana) + '%';
    document.getElementById('enemy-count').innerText = enemies.length;
}

function resetGame() {
    player.hp = player.maxHp;
    player.mana = 100;
    player.shield = 0;
    player.buffs.rapidFire = 0;
    player.x = CX;
    player.y = CY + 200;
    
    enemies = [];
    projectiles = [];
    particles = [];
    comboSequence = [];
    comboTimer = 0;
    
    currentWave = 1;
    gameOver = false;
    
    spawnWave(currentWave);
    gameLoop();
}

function gameLoop() {
    drawEnvironment();
    
    if (player.hp > 0) player.update();
    player.draw(); 
    
    for (let i = enemies.length - 1; i >= 0; i--) {
        let ai = enemies[i];
        ai.update();
        ai.draw();
        
        if (ai.hp <= 0) {
            spawnParticles(ai.x, ai.y, '#ffffff', 30);
            enemies.splice(i, 1);
        }
    }

    for (let i = projectiles.length - 1; i >= 0; i--) {
        let p = projectiles[i]; p.update(); p.draw();
        
        if (p.x < 0 || p.x > canvas.width || p.y < 0 || p.y > canvas.height) { projectiles.splice(i, 1); continue; }
        
        let hit = false;
        if (p.owner === 'player') {
            for (let e of enemies) {
                if (distance(p.x, p.y, e.x, e.y) < (e.radius * e.scale) + p.radius) {
                    if (e.shield <= 0) { e.hp -= p.damage; playSound('hit'); }
                    hit = true; break;
                }
            }
        } else if (p.owner === 'ai' && distance(p.x, p.y, player.x, player.y) < player.radius + p.radius) {
            if (player.shield <= 0) { player.hp -= p.damage; playSound('hit'); }
            hit = true;
        }
        
        if (hit) { projectiles.splice(i, 1); }
    }

    for (let i = particles.length - 1; i >= 0; i--) {
        let pt = particles[i]; pt.x += pt.vx; pt.y += pt.vy; pt.life--;
        ctx.fillStyle = pt.color; ctx.globalAlpha = pt.life / 25;
        ctx.fillRect(pt.x, pt.y, 6, 6); 
        ctx.globalAlpha = 1.0;
        if (pt.life <= 0) particles.splice(i, 1);
    }
    
    updateUI();
    
    if (enemies.length === 0 && player.hp > 0) {
        currentWave++;
        spawnWave(currentWave);
        player.hp = Math.min(100, player.hp + 35); 
    }
    
    if (player.hp <= 0) { 
        gameOver = true;
        ctx.fillStyle = 'rgba(0,0,0,0.85)'; ctx.fillRect(0,0,canvas.width,canvas.height);
        
        ctx.fillStyle = '#e65c5c'; ctx.font = '60px "Press Start 2P"'; ctx.textAlign = "center";
        ctx.fillText("SYSTEM FAILURE", canvas.width/2, canvas.height/2 - 30); 
        
        ctx.fillStyle = '#a1b0b5'; ctx.font = '20px "Press Start 2P"';
        ctx.fillText(`Nodes Cleared: ${currentWave - 1}`, canvas.width/2, canvas.height/2 + 30); 
        
        ctx.fillStyle = '#00e5ff'; ctx.font = '16px "Press Start 2P"';
        ctx.fillText("CLICK ANYWHERE TO REBOOT", canvas.width/2, canvas.height/2 + 90);
    } else { 
        requestAnimationFrame(gameLoop); 
    }
}

drawEnvironment();
ctx.fillStyle = 'white'; ctx.font = '30px "Press Start 2P"'; ctx.textAlign = "center";
ctx.fillText("INITIALIZE SYSTEM", canvas.width/2, canvas.height/2);

window.addEventListener('click', () => {
    if (!started) { 
        started = true; 
        playSound('charge'); 
        spawnWave(currentWave); 
        gameLoop(); 
    } else if (gameOver) {
        playSound('charge');
        resetGame();
    }
});